package com.kamalpurbites

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.graphics.Color

data class Food(val name: String, val description: String, val price: Int, val restaurant: String)

class MainActivity : Activity() {
    private val whatsappNumber = "919863396169"
    private val foods = listOf(
        Food("Veg Thali", "शाकाहारी थाली", 120, "Kamalpur Kitchen"),
        Food("Chicken Meal", "चिकन के साथ भोजन", 180, "Kamalpur Kitchen"),
        Food("Veg Chowmein", "सब्ज़ियों वाली चाउमीन", 80, "Town Snacks"),
        Food("Chicken Burger", "चिकन बर्गर", 110, "Town Snacks"),
        Food("Momos", "गरमागरम मोमोज़", 70, "Town Snacks"),
        Food("Tea", "गरम चाय", 20, "Tea Corner"),
        Food("Cold Coffee", "ठंडी कॉफी", 60, "Tea Corner"),
        Food("Egg Roll", "अंडा रोल", 60, "Town Snacks")
    )
    private val cart = linkedMapOf<String, Int>()
    private lateinit var root: LinearLayout
    private lateinit var cartSummary: TextView
    private lateinit var totalView: TextView
    private lateinit var nameInput: EditText
    private lateinit var phoneInput: EditText
    private lateinit var addressInput: EditText
    private lateinit var searchInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246, 250, 247))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 18, 18, 28)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, -1))
        setContentView(root)

        content.addView(label("🍽️ Kamalpur Bites", 28, true, Color.rgb(20, 99, 59)))
        content.addView(label("Kamalpur का अपना food delivery app", 16, false, Color.DKGRAY))
        content.addView(label("Demo version: restaurant list और order draft. अभी real restaurant login या online database नहीं है.", 13, false, Color.rgb(130, 80, 0)))
        searchInput = EditText(this).apply { hint = "खाना या restaurant खोजें"; singleLine = true }
        content.addView(searchInput)
        val menuContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(menuContainer)
        searchInput.addTextChangedListener(SimpleTextWatcher { renderMenu(menuContainer) })
        renderMenu(menuContainer)

        content.addView(label("🛒 आपका Cart", 22, true, Color.rgb(20, 59, 42)))
        cartSummary = label("अभी cart खाली है।", 16, false, Color.DKGRAY)
        content.addView(cartSummary)
        totalView = label("कुल: ₹0", 20, true, Color.rgb(20, 99, 59))
        content.addView(totalView)

        content.addView(label("📍 Delivery details", 22, true, Color.rgb(20, 59, 42)))
        nameInput = EditText(this).apply { hint = "आपका नाम"; singleLine = true }
        phoneInput = EditText(this).apply { hint = "आपका मोबाइल नंबर"; singleLine = true; inputType = 3 }
        addressInput = EditText(this).apply { hint = "पूरा delivery पता"; minLines = 2; gravity = Gravity.TOP }
        content.addView(nameInput); content.addView(phoneInput); content.addView(addressInput)
        val send = Button(this).apply {
            text = "WhatsApp पर ऑर्डर भेजें"
            setBackgroundColor(Color.rgb(22, 116, 71))
            setTextColor(Color.WHITE)
            setOnClickListener { sendOrder() }
        }
        content.addView(send)
        content.addView(label("नोट: WhatsApp खुलेगा; ग्राहक को Send दबाना होगा। डिलीवरी चार्ज दुकान से confirm करें।", 13, false, Color.DKGRAY))
    }

    private fun label(text: String, size: Int, bold: Boolean, color: Int): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, 8, 0, 8)
        }

    private fun renderMenu(container: LinearLayout) {
        container.removeAllViews()
        val query = searchInput.text.toString().trim().lowercase()
        foods.filter { it.name.lowercase().contains(query) || it.restaurant.lowercase().contains(query) }
            .forEach { food ->
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(12, 8, 12, 8)
                    setBackgroundColor(Color.WHITE)
                }
                card.addView(label(food.name + "  ·  ₹" + food.price, 18, true, Color.rgb(25, 70, 45)))
                card.addView(label(food.restaurant + " — " + food.description, 14, false, Color.DKGRAY))
                val add = Button(this).apply {
                    text = "+ Cart में डालें"
                    setOnClickListener { cart[food.name] = (cart[food.name] ?: 0) + 1; updateCart() }
                }
                card.addView(add)
                val lp = LinearLayout.LayoutParams(-1, -2)
                lp.setMargins(0, 7, 0, 7)
                container.addView(card, lp)
            }
    }

    private fun updateCart() {
        cartSummary.text = if (cart.isEmpty()) "अभी cart खाली है।" else cart.entries.joinToString("\n") { "${it.key} × ${it.value}" }
        totalView.text = "कुल: ₹" + cart.entries.sumOf { entry ->
            val price = foods.first { it.name == entry.key }.price
            price * entry.value
        }
    }

    private fun sendOrder() {
        if (cart.isEmpty()) { Toast.makeText(this, "पहले cart में खाना जोड़ें", Toast.LENGTH_SHORT).show(); return }
        val name = nameInput.text.toString().trim()
        val phone = phoneInput.text.toString().trim()
        val address = addressInput.text.toString().trim()
        if (name.isBlank() || phone.isBlank() || address.isBlank()) {
            Toast.makeText(this, "नाम, मोबाइल और पता भरें", Toast.LENGTH_SHORT).show(); return
        }
        val itemsText = cart.entries.joinToString("\n") {
            val f = foods.first { f -> f.name == it.key }
            "• ${f.name} × ${it.value} = ₹${f.price * it.value} (${f.restaurant})"
        }
        val total = cart.entries.sumOf { foods.first { f -> f.name == it.key }.price * it.value }
        val message = "नमस्ते Kamalpur Bites! मुझे ऑर्डर करना है।\n\n$itemsText\n\nकुल: ₹$total (डिलीवरी चार्ज confirm करें)\nनाम: $name\nग्राहक मोबाइल: $phone\nपता: $address\nकृपया order और delivery charge confirm करें।"
        val uri = Uri.parse("https://wa.me/$whatsappNumber?text=" + Uri.encode(message))
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        catch (_: Exception) { Toast.makeText(this, "WhatsApp या browser उपलब्ध नहीं है", Toast.LENGTH_LONG).show() }
    }
}

class SimpleTextWatcher(private val onChange: () -> Unit) : android.text.TextWatcher {
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { onChange() }
    override fun afterTextChanged(s: android.text.Editable?) {}
}
