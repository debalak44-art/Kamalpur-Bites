plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.kamalpurbites"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.kamalpurbites"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-demo"
    }
}
