# Kamalpur Bites Android Starter (Kotlin)

यह Android Studio के लिए शुरुआती source project है। इसमें ग्राहक food list, cart, customer details और WhatsApp पर order भेजने का शुरुआती flow है। यह अभी multi-restaurant production app नहीं है और न ही APK है।

## ज़रूरी बातें
- Android app बनाने/build करने के लिए Android Studio वाला computer या cloud build service चाहिए। केवल Android फोन पर source code से APK बनाना कठिन हो सकता है।
- यह starter demo data इस्तेमाल करता है। अभी login, server/database, restaurant owner panel, admin approval, payment, delivery tracking, notifications या online hosting नहीं है।
- WhatsApp number `919863396169` demo में सेट है। WhatsApp message भेजने से पहले user को WhatsApp में Send दबाना होगा।
- Publish करने से पहले menu/prices, delivery radius, privacy policy, terms, order handling, and security जोड़ना ज़रूरी है।

## Build करने का आसान रास्ता
1. किसी कंप्यूटर पर Android Studio install करें।
2. Android Studio में Open चुनकर इस folder को खोलें।
3. Gradle sync होने दें; Android Gradle Plugin/Kotlin version जरूरत के अनुसार update हो सकते हैं।
4. Android phone पर Developer Options > USB debugging enable करके Run करें, या emulator इस्तेमाल करें।
5. Production multi-restaurant system के लिए backend/database और restaurant/admin dashboard अलग से बनाना होगा।

## इस starter में
- Menu cards और search
- Cart quantity controls
- Customer name, phone, address
- WhatsApp order draft
